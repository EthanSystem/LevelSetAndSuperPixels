# README

The original BSDS500 [1] does not provide any README. The converted dataset
will be made available if possible.

    [1] P. Arbelaez, M. Maire, C. Fowlkes, J. Malik.
        Contour detection and hierarchical image segmentation.
        IEEE Transactions on Pattern Analysis and Machine Intelligence 33 (5) (2011) 898-916.

Instructions to convert the dataset manually can be found in `docs/DATASETS.md`.
