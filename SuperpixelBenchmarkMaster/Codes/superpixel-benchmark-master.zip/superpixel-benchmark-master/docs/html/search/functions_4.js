var searchData=
[
  ['enforceminimumsegmentsize',['enforceMinimumSegmentSize',['../classGraphSegmentation.html#ac291f9cab74444444d9130b727d61721',1,'GraphSegmentation']]],
  ['enforceminimumsuperpixelsize',['enforceMinimumSuperpixelSize',['../classSuperpixelTools.html#a17d54c4d603b7c33e49462110e98d07f',1,'SuperpixelTools']]],
  ['enforceminimumsuperpixelsizeupto',['enforceMinimumSuperpixelSizeUpTo',['../classSuperpixelTools.html#a5aaf0277c4c0b811c97994ca777c8fb1',1,'SuperpixelTools']]],
  ['evaluate',['evaluate',['../classEvaluationSummary.html#a07f532b5dbeb8c6e4d01181f73aa05d3',1,'EvaluationSummary::evaluate()'],['../classRobustnessTool.html#a6526776a0b0ad94695c4161dea902a7f',1,'RobustnessTool::evaluate()']]],
  ['evaluateheader',['evaluateHeader',['../classEvaluationSummary.html#a2474d06a303bc4de424803c974446b9b',1,'EvaluationSummary']]],
  ['evaluationmetrics',['EvaluationMetrics',['../structEvaluationSummary_1_1EvaluationMetrics.html#a58ce0f7c5bb14b41d87168ee8e0c3e96',1,'EvaluationSummary::EvaluationMetrics']]],
  ['evaluationstatistics',['EvaluationStatistics',['../structEvaluationSummary_1_1EvaluationStatistics.html#a06a08a1e04ac6e8fd1c54929d3e2e9d1',1,'EvaluationSummary::EvaluationStatistics']]],
  ['evaluationsummary',['EvaluationSummary',['../classEvaluationSummary.html#a7782fc8c4abf2385adcea8e4717a5079',1,'EvaluationSummary::EvaluationSummary(boost::filesystem::path sp_directory, boost::filesystem::path gt_directory, boost::filesystem::path img_directory)'],['../classEvaluationSummary.html#ab300f921529332a55277b177a1e16caa',1,'EvaluationSummary::EvaluationSummary(boost::filesystem::path sp_directory, boost::filesystem::path gt_directory, boost::filesystem::path img_directory, EvaluationMetrics evaluation_metrics, EvaluationStatistics evaluation_statistics)'],['../classEvaluationSummary.html#ae9949a6a8d15c7dee05770aadc22c038',1,'EvaluationSummary::EvaluationSummary(boost::filesystem::path sp_directory, boost::filesystem::path gt_directory, boost::filesystem::path img_directory, EvaluationMetrics evaluation_metrics, EvaluationStatistics evaluation_statistics, SuperpixelVisualizations superpixel_visualizations)']]]
];
