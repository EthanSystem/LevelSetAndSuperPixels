var searchData=
[
  ['lsc_5fopencv',['LSC_OpenCV',['../classLSC__OpenCV.html',1,'']]]
];
