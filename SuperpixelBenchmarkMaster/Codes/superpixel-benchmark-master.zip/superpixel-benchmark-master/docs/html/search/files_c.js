var searchData=
[
  ['slic_5fopencv_2ecpp',['slic_opencv.cpp',['../slic__opencv_8cpp.html',1,'']]],
  ['slic_5fopencv_2eh',['slic_opencv.h',['../slic__opencv_8h.html',1,'']]],
  ['submission_2emd',['SUBMISSION.md',['../SUBMISSION_8md.html',1,'']]],
  ['superpixel_5ftools_2ecpp',['superpixel_tools.cpp',['../superpixel__tools_8cpp.html',1,'']]],
  ['superpixel_5ftools_2eh',['superpixel_tools.h',['../superpixel__tools_8h.html',1,'']]]
];
