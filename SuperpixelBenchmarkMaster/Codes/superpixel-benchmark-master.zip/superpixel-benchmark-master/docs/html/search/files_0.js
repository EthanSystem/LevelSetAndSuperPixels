var searchData=
[
  ['algorithms_2emd',['ALGORITHMS.md',['../ALGORITHMS_8md.html',1,'']]]
];
