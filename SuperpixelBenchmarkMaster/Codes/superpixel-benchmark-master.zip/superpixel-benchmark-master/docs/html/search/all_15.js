var searchData=
[
  ['_7egraphsegmentation',['~GraphSegmentation',['../classGraphSegmentation.html#a9f248edb298452087cb3f744e3446e7b',1,'GraphSegmentation']]],
  ['_7egraphsegmentationdistance',['~GraphSegmentationDistance',['../classGraphSegmentationDistance.html#a6634893a2a73f01b8f75f6362bc84065',1,'GraphSegmentationDistance']]]
];
