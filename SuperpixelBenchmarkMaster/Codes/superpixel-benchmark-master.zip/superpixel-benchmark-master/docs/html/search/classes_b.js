var searchData=
[
  ['saltandpeppernoisedriver',['SaltAndPepperNoiseDriver',['../classSaltAndPepperNoiseDriver.html',1,'']]],
  ['scost',['scost',['../structscost.html',1,'']]],
  ['sheardriver',['ShearDriver',['../classShearDriver.html',1,'']]],
  ['slic_5fopencv',['SLIC_OpenCV',['../classSLIC__OpenCV.html',1,'']]],
  ['superpixeltools',['SuperpixelTools',['../classSuperpixelTools.html',1,'']]],
  ['superpixelvisualizations',['SuperpixelVisualizations',['../structEvaluationSummary_1_1SuperpixelVisualizations.html',1,'EvaluationSummary']]]
];
