var searchData=
[
  ['oe',['oe',['../structEvaluationSummary_1_1EvaluationMetrics.html#aa20793669dab8b95207f1bfa27edff6e',1,'EvaluationSummary::EvaluationMetrics']]],
  ['operator_28_29',['operator()',['../classGraphSegmentationDistance.html#a8c52505f60a3e1ab795b03be459ea97c',1,'GraphSegmentationDistance::operator()()'],['../classGraphSegmentationManhattenRGB.html#abaaffdb864a1c47e96f9210210e76004',1,'GraphSegmentationManhattenRGB::operator()()'],['../classGraphSegmentationEuclideanRGB.html#ad43ad4e5f970dc8da316a4184b0baac1',1,'GraphSegmentationEuclideanRGB::operator()()'],['../classGraphSegmentationMagic.html#a5380c510f012bd3c0a64c11371401f65',1,'GraphSegmentationMagic::operator()()'],['../classGraphSegmentationMagicThreshold.html#a9572546f7b6961c62f4d6e7f5983bd0c',1,'GraphSegmentationMagicThreshold::operator()()'],['../classImageEdgeSorter.html#a4ffebd8c846a180f3a1f4a1a41528c34',1,'ImageEdgeSorter::operator()()']]],
  ['operator_3d',['operator=',['../classImageGraph.html#a07da5c2a67a5ddc3deea92596a81f997',1,'ImageGraph']]],
  ['optimize',['optimize',['../classParameterOptimizationTool.html#a7fe8f6461faeee0c584546cf2f68bb49',1,'ParameterOptimizationTool']]],
  ['oversegmentgraph',['oversegmentGraph',['../classGraphSegmentation.html#a1e4c4e94fd60527bc7c395e514166d4f',1,'GraphSegmentation']]]
];
