var searchData=
[
  ['validatestatistics',['validateStatistics',['../classEvaluationSummary.html#af2dfd3e2dace54fa88a370368cfb27f1',1,'EvaluationSummary']]],
  ['visualize',['visualize',['../classEvaluationSummary.html#a68d0646d58bc422c61086ad7aa1881bd',1,'EvaluationSummary']]]
];
