var searchData=
[
  ['applyhorizontalshear_3c_20cv_3a_3avec3b_20_3e',['applyHorizontalShear&lt; cv::Vec3b &gt;',['../transformation_8cpp.html#aaba7e37e85c443346443994a58e5d1f2',1,'transformation.cpp']]],
  ['applyrotation_3c_20cv_3a_3avec3b_20_3e',['applyRotation&lt; cv::Vec3b &gt;',['../transformation_8cpp.html#ab4c9c67d81275adc14492628c58c61ff',1,'transformation.cpp']]],
  ['applytranslation_3c_20cv_3a_3avec3b_20_3e',['applyTranslation&lt; cv::Vec3b &gt;',['../transformation_8cpp.html#a2a67a3b12207118ebde340f02d9241b7',1,'transformation.cpp']]],
  ['applyverticalshear_3c_20cv_3a_3avec3b_20_3e',['applyVerticalShear&lt; cv::Vec3b &gt;',['../transformation_8cpp.html#a7f4e4dfaea1307e01a15a303638dd9f4',1,'transformation.cpp']]],
  ['transformation',['Transformation',['../classTransformation.html',1,'']]],
  ['transformation_2ecpp',['transformation.cpp',['../transformation_8cpp.html',1,'']]],
  ['transformation_2eh',['transformation.h',['../transformation_8h.html',1,'']]],
  ['translationdriver',['TranslationDriver',['../classTranslationDriver.html',1,'TranslationDriver'],['../classTranslationDriver.html#a52e4af33b120493f20a4884b37896138',1,'TranslationDriver::TranslationDriver()']]],
  ['tuple',['TUPLE',['../parameter__optimization__tool_8cpp.html#a46bcdbe1cc22cce7435829d4d0df85ea',1,'parameter_optimization_tool.cpp']]]
];
